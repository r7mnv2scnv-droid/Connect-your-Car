import SwiftUI

@main
struct MyApp: App {
    @StateObject private var systemManager = CarSystemManager()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(systemManager)
        }
    }
}

