import SwiftUI

// MARK: - LOKALISIERUNG & SPRACHE (i18n)
enum Language: String {
    case de = "de"
    case en = "en"
    case es = "es"
    
    static var current: Language {
        let locale = Locale.current.language.languageCode?.identifier ?? "en"
        return Language(rawValue: locale) ?? .en
    }
}

struct LocalizedStrings {
    let startDashboard: String
    let appsTitle: String
    let settingsTitle: String
    let duckingLabel: String
    let connectionLabel: String
    let activeNav: String
    let activeMedia: String
    let calendarEvent: String
    
    static func get() -> LocalizedStrings {
        switch Language.current {
        case .de:
            return LocalizedStrings(
                startDashboard: "Dashboard starten", appsTitle: "Apps", settingsTitle: "Einstellungen",
                duckingLabel: "Audio-Ducking Intensität", connectionLabel: "Verbindung",
                activeNav: "Route aktiv", activeMedia: "Läuft gerade", calendarEvent: "Nächster Termin: 14:00 Uhr Team Sync"
            )
        case .es:
            return LocalizedStrings(
                startDashboard: "Iniciar Dashboard", appsTitle: "Aplicaciones", settingsTitle: "Ajustes",
                duckingLabel: "Intensidad de Atenuación", connectionLabel: "Conexión",
                activeNav: "Ruta activa", activeMedia: "Reproduciendo", calendarEvent: "Próxima cita: 14:00 PM Team Sync"
            )
        default: // en
            return LocalizedStrings(
                startDashboard: "Start Dashboard", appsTitle: "Apps", settingsTitle: "Settings",
                duckingLabel: "Audio Ducking Intensity", connectionLabel: "Connection",
                activeNav: "Active Route", activeMedia: "Now Playing", calendarEvent: "Next Event: 2:00 PM Team Sync"
            )
        }
    }
}

// MARK: - DATENMODELLE & APP-DEFINITIONEN
struct AppModel: Identifiable, Hashable {
    let id: String
    let name: String
    let iconName: String
    let category: AppCategory
    var isEnabled: Bool
}

enum AppCategory {
    case navigation, media, communication
}

// MARK: - STATE-MANAGEMENT & SESSION MANAGERS
class CarSystemManager: ObservableObject {
    @Published var isCarPlayActive: Bool = false
    @Published var installedApps: [AppModel] = [
        AppModel(id: "calimoto", name: "Calimoto", iconName: "map.circle.fill", category: .navigation, isEnabled: true),
        AppModel(id: "kurviger", name: "Kurviger", iconName: "location.circle.fill", category: .navigation, isEnabled: true),
        AppModel(id: "googlemaps", name: "Google Maps", iconName: "map", category: .navigation, isEnabled: false),
        AppModel(id: "spotify", name: "Spotify", iconName: "music.note.house.fill", category: .media, isEnabled: true),
        AppModel(id: "applemusic", name: "Apple Music", iconName: "music.note", category: .media, isEnabled: true),
        AppModel(id: "whatsapp", name: "WhatsApp", iconName: "message.fill", category: .communication, isEnabled: true)
    ]
    
    @Published var activeNavigationApp: AppModel?
    @Published var activeMediaApp: AppModel?
    @Published var recentAppsHistory: [AppModel] = []
    
    @Published var audioDuckingIntensity: Double = 0.3
    @Published var isDuckingActive: Bool = false
    @Published var isNavMuted: Bool = false // Steuert Stummmodus der Navigation
    
    let strings = LocalizedStrings.get()
    
    init() {
        self.activeNavigationApp = installedApps.first(where: { $0.category == .navigation && $0.isEnabled })
        self.activeMediaApp = installedApps.first(where: { $0.category == .media && $0.isEnabled })
        updateHistory()
    }
    
    func switchNavigationSession(to app: AppModel) {
        guard app.category == .navigation else { return }
        triggerAudioDucking()
        activeNavigationApp = app
        updateHistory()
    }
    
    func switchMediaSession(to app: AppModel) {
        guard app.category == .media else { return }
        activeMediaApp = app
        updateHistory()
    }
    
    private func triggerAudioDucking() {
        // Wenn stummgeschaltet, blockiere das Ducking
        guard !isNavMuted else { return }
        
        withAnimation { isDuckingActive = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            withAnimation { self.isDuckingActive = false }
        }
    }
    
    func updateHistory() {
        var history: [AppModel] = []
        if let nav = activeNavigationApp, nav.isEnabled { history.append(nav) }
        if let med = activeMediaApp, med.isEnabled { history.append(med) }
        if let comm = installedApps.first(where: { $0.category == .communication && $0.isEnabled }) {
            history.append(comm)
        }
        self.recentAppsHistory = history
    }
}

// MARK: - MAIN CONTENT VIEW
struct ContentView: View {
    @EnvironmentObject var manager: CarSystemManager
    
    var body: some View {
        ZStack {
            if !manager.isCarPlayActive {
                PortraitConfiguratorView()
            } else {
                CarPlayLandscapeView()
            }
        }
        .animation(.default, value: manager.isCarPlayActive)
    }
}

// MARK: - PORTRAIT-LAYOUT (CONFIGURATOR)
struct PortraitConfiguratorView: View {
    @EnvironmentObject var manager: CarSystemManager
    
    var body: some View {
        TabView {
            VStack(spacing: 30) {
                Spacer()
                Image(systemName: "car.vfill")
                    .font(.system(size: 80))
                    .foregroundColor(.blue)
                
                Button(action: {
                    manager.isCarPlayActive = true
                }) {
                    Text(manager.strings.startDashboard)
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(12)
                        .padding(.horizontal, 40)
                }
                Spacer()
            }
            .tabItem {
                Label("Dashboard", systemImage: "square.grid.2x2.fill")
            }
            
            NavigationStack {
                List($manager.installedApps) { $app in
                    HStack {
                        Image(systemName: app.iconName)
                            .font(.title2)
                            .frame(width: 40)
                        Text(app.name)
                        Spacer()
                        Toggle("", isOn: $app.isEnabled)
                            .onChange(of: app.isEnabled) { _ in
                                manager.updateHistory()
                            }
                    }
                }
                .navigationTitle(manager.strings.appsTitle)
            }
            .tabItem {
                Label(manager.strings.appsTitle, systemImage: "apps.iphone")
            }
            
            NavigationStack {
                Form {
                    Section(header: Text(manager.strings.duckingLabel)) {
                        HStack {
                            Text("Dämpfung:")
                            Slider(value: $manager.audioDuckingIntensity, in: 0.1...0.8)
                        }
                    }
                    Section(header: Text(manager.strings.connectionLabel)) {
                        Text("Protokoll: Wireless CarPlay (Simuliert)")
                        Text("Architektur: ARM64 / Swift v6")
                    }
                }
                .navigationTitle(manager.strings.settingsTitle)
            }
            .tabItem {
                Label(manager.strings.settingsTitle, systemImage: "gearshape.fill")
            }
        }
    }
}

// MARK: - CARPLAY LANDSCAPE VIEW (QUERFORMAT)
enum CarPlayScreenMode {
    case dashboard, springboard
}

struct CarPlayLandscapeView: View {
    @EnvironmentObject var manager: CarSystemManager
    @State private var currentMode: CarPlayScreenMode = .dashboard
    
    var body: some View {
        HStack(spacing: 0) {
            VStack(spacing: 15) {
                VStack {
                    Text("12:00")
                        .font(.system(size: 14, weight: .bold))
                    Image(systemName: "cellularbars")
                        .font(.caption2)
                }
                .foregroundColor(.white)
                
                Spacer()
                
                VStack(spacing: 12) {
                    ForEach(manager.recentAppsHistory) { app in
                        Button(action: {
                            if app.category == .navigation { manager.switchNavigationSession(to: app) }
                            if app.category == .media { manager.switchMediaSession(to: app) }
                        }) {
                            Image(systemName: app.iconName)
                                .font(.title3)
                                .foregroundColor(.white)
                                .frame(width: 36, height: 36)
                                .background(Color.gray.opacity(0.3))
                                .clipShape(Circle())
                        }
                    }
                }
                
                Spacer()
                
                Button(action: {
                    currentMode = (currentMode == .dashboard) ? .springboard : .dashboard
                }) {
                    Image(systemName: currentMode == .dashboard ? "circle.grid.2x2.fill" : "circle.inset.filled")
                        .font(.title)
                        .foregroundColor(.white)
                }
            }
            .padding(.vertical, 10)
            .frame(width: 60)
            .background(Color.black.opacity(0.9))
            
            ZStack {
                Color.black.ignoresSafeArea()
                
                if currentMode == .dashboard {
                    DashboardSplitScreenView()
                } else {
                    SpringBoardView()
                }
            }
        }
    }
}

// MARK: - DASHBOARD SPLIT-SCREEN LAYOUT
struct DashboardSplitScreenView: View {
    @EnvironmentObject var manager: CarSystemManager
    
    var body: some View {
        HStack(spacing: 8) {
            // WIDGET 1: Navigation mit Mute-Button
            VStack(alignment: .leading) {
                HStack {
                    Image(systemName: manager.activeNavigationApp?.iconName ?? "map")
                    Text(manager.activeNavigationApp?.name ?? "Keine Navigations-App")
                        .font(.headline)
                    
                    Spacer()
                    
                    // Interaktiver Mute-Button
                    Button(action: {
                        manager.isNavMuted.toggle()
                    }) {
                        Image(systemName: manager.isNavMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                            .font(.body)
                            .foregroundColor(manager.isNavMuted ? .red : .blue)
                            .padding(8)
                            .background(Color.black.opacity(0.2))
                            .clipShape(Circle())
                    }
                    
                    Text(manager.strings.activeNav).font(.caption).opacity(0.7)
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                
                GeometryReader { geo in
                    ZStack {
                        Color.gray.opacity(0.1)
                        VStack(alignment: .leading, spacing: 5) {
                            HStack {
                                Image(systemName: "arrow.turn.up.right")
                                    .font(.title)
                                Text("In 200m rechts abbiegen")
                                    .font(.subheadline)
                            }
                            Text("Ziel via Dynamic Route Engine")
                                .font(.caption2)
                                .opacity(0.6)
                        }
                        .padding(10)
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(8)
                        .position(x: geo.size.width / 2, y: 40)
                    }
                    .gesture(DragGesture(minimumDistance: 0).onEnded { value in
                        print("Touch Event: X: \(value.location.x), Y: \(value.location.y)")
                    })
                }
            }
            .frame(maxWidth: .infinity)
            .background(Color.black.opacity(0.4))
            .cornerRadius(12)
            
            // RECHTE MULTITASKING-SPALTE
            VStack(spacing: 8) {
                // WIDGET 2: Media Stream Container
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Image(systemName: manager.activeMediaApp?.iconName ?? "music.note")
                            .foregroundColor(.blue)
                        Text(manager.activeMediaApp?.name ?? "Keine Medien")
                            .font(.subheadline)
                            .bold()
                        Spacer()
                        if manager.isDuckingActive {
                            Text("Ducking").font(.caption2).foregroundColor(.orange)
                        }
                    }
                    
                    Spacer()
                    Text("Dynamic Audio Stream").font(.caption)
                    Spacer()
                    
                    HStack {
                        Image(systemName: "backward.fill")
                        Spacer()
                        Image(systemName: "play.fill").font(.title2)
                        Spacer()
                        Image(systemName: "forward.fill")
                    }
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.gray.opacity(0.15))
                .cornerRadius(12)
                .opacity(manager.isDuckingActive ? manager.audioDuckingIntensity : 1.0)
                
                // WIDGET 3: Kalender / Benachrichtigung
                VStack(alignment: .leading) {
                    HStack {
                        Image(systemName: "calendar").foregroundColor(.red)
                        Text("Kalender").font(.caption).bold()
                    }
                    Spacer()
                    Text(manager.strings.calendarEvent)
                        .font(.caption2)
                        .lineLimit(2)
                    Spacer()
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.gray.opacity(0.15))
                .cornerRadius(12)
            }
            .frame(width: 240)
        }
        .padding(8)
    }
}

// MARK: - SPRINGBOARD (APP GRID)
struct SpringBoardView: View {
    @EnvironmentObject var manager: CarSystemManager
    
    var activeApps: [AppModel] {
        manager.installedApps.filter { $0.isEnabled }
    }
    
    let columns = [GridItem(.adaptive(minimum: 70, maximum: 90))]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(activeApps) { app in
                    Button(action: {
                        if app.category == .navigation { manager.switchNavigationSession(to: app) }
                        if app.category == .media { manager.switchMediaSession(to: app) }
                    }) {
                        VStack {
                            Image(systemName: app.iconName)
                                .font(.system(size: 35))
                                .foregroundColor(.white)
                                .frame(width: 60, height: 60)
                                .background(Color.blue.gradient)
                                .cornerRadius(14)
                            Text(app.name)
                                .font(.caption2)
                                .foregroundColor(.white)
                        }
                    }
                }
                
                Button(action: { manager.isCarPlayActive = false }) {
                    VStack {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 35))
                            .foregroundColor(.white)
                            .frame(width: 60, height: 60)
                            .background(Color.red.gradient)
                            .cornerRadius(14)
                        Text("Exit").font(.caption2).foregroundColor(.white)
                    }
                }
            }
            .padding(20)
        }
    }
}

